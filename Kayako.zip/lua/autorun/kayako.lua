player_manager.AddValidModel( "Kayako", "models/kayako/kayako.mdl" )

AddCSLuaFile( 'kayako.lua' )

list.Set( "PlayerOptionsModel", "Kayako", "models/kayako/kayako.mdl" )