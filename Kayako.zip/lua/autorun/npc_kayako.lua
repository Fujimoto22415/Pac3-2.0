local Category = "Humans + Resistance"

local NPC = { 	Name = "Kayako", 
				Class = "npc_Citizen",
				Model = "models/kayako/kayako.mdl",
				Health = "100",
				KeyValues = { citizentype = 4 },
				Category = Category	}


list.Set( "NPC", "npc_kayako", NPC )